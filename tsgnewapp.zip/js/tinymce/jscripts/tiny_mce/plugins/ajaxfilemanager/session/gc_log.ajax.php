<?php die(); ?>
gc start at 07/Oct/2013 11:12:01
